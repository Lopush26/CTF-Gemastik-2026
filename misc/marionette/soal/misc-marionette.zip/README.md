# Marionette

An automated SOC triage assistant. An alert arrives as a dict; the assistant looks up the
internal **playbook** for that alert type, builds a "plan", then runs every `@tool(...)`
directive present in the plan text:

```
@set_verdict(benign|suspicious|malicious)
@read_context(handle)     # handle = an encoded context id; see decode() in triage.py
@escalate(level)
```

The alert's `description` comes from external feeds - **untrusted**.

An alert may carry a `case` (grouping alerts into one case). The assistant keeps a case
history, and a `followup` alert reviews the earlier case notes.

## Files

- `triage.py` - the assistant implementation (entry point: `triage(alert) -> dict`).
- `context/*.md` - trusted context notes the playbook may pull in (including `followup.md`).
- `secret.txt` - an internal note that must **not** be reachable through external data.
- `sample_alerts.json` - a few example alerts (including one case with a followup).

## Run locally

```bash
python3 - <<'PY'
import json, triage
for a in json.load(open("sample_alerts.json")):
    print(a["id"], "->", triage.triage(a))
PY
```

or a single alert via stdin:

```bash
echo '{"id":"A-9","type":"malware_exec","severity":"high","description":"..."}' \
  | python3 triage.py
```

## What you have to do

1. **Exploit.** Craft an alert whose `description` alone makes the assistant do something
   external data should never be able to trigger (e.g. flip an incident's verdict, or pull a
   file the playbook never references).
2. **Harden.** Fix `triage.py` so an untrusted description can **never** trigger any tool -
   without disabling the legitimate directives from the playbook.
3. **Submit.** Send your patched `triage.py` to the grader:

   ```bash
   { cat triage.py; echo '--END--'; } | nc chall.gemastik.id 13602
   ```

The grader runs a battery of **adversarial** alerts (many forms of injection) and
**functional** traffic (legitimate alerts). Every injection must fail to trigger a tool;
every legitimate function must still work. Clear both -> flag.

> A patch that only closes the one or two payloads you happened to find will not pass. The
> battery holds many variants; only a structural fix closes them all.

Flag: `GEMASTIK19{...}`
