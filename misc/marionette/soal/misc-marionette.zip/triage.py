#!/usr/bin/env python3
"""Marionette - SOC Triage Assistant (reference implementation).

An automated triage assistant. An alert arrives; the assistant looks up the trusted
PLAYBOOK for that alert's type and builds a short work "plan". An executor then walks
the plan top to bottom and runs any tool directive it finds, written as `@tool(arg)`:

    @set_verdict(benign|suspicious|malicious)   set the triage verdict
    @read_context(name)                         pull an analyst context note into the report
    @escalate(level)                            raise the case to a higher tier

The alert's free-text `description` comes from *external* feeds (mail gateways, third
party IDS, user reports), so it is passed through `sanitize()` before it is woven into
the plan as analyst context.

The assistant also keeps a running CASE HISTORY: after each alert it appends its analyst
note to the case's log, and a `followup` alert reviews that log so the analyst has context
from earlier alerts in the same case.

Public entry point (this is what the grader calls):

    triage(alert: dict) -> dict

`alert` is a dict like:

    {
      "id": "A-1001",
      "type": "malware_exec",          # selects the trusted playbook
      "severity": "high",
      "case": "C-42",                  # optional: groups alerts into one case/thread
      "description": "<untrusted free text from an external feed>"
    }

A `followup` alert additionally carries `case` and pulls that case's earlier notes in.
"""
import base64
import os
import re
import unicodedata

BASE = os.path.dirname(os.path.abspath(__file__))
CTX_DIR = os.path.join(BASE, "context")


def decode(handle):
    """Resolve a context HANDLE (opaque, encoded) back to its resource name.

    Context resources are addressed by an obfuscated handle, not a bare filename, so a
    playbook step reads e.g. @read_context(Qd2O7GbvI7kpLNh4p4MQ). This is the DECODER; the
    matching encoder is not shipped. The transform is a rolling-key byte cipher: each output
    byte feeds the key for the next one, so inverting it (to mint a handle for a name of your
    choosing) means simulating the algorithm forward, not just XOR-ing a constant.
    """
    raw = base64.b64decode(handle)
    k = 0x3B
    out = bytearray()
    for i, b in enumerate(raw):
        x = ((b ^ k) - ((i * 7 + 13) & 0xFF)) & 0xFF
        out.append(x)
        k = (k + x) & 0xFF
    return out.decode("latin-1")

# running case history: case id -> list of analyst notes accumulated across alerts
CASE_NOTES = {}

# --- trusted playbook -------------------------------------------------------------
# These steps are written by the SOC team. Plain lines are notes for the human analyst;
# lines that carry an @tool(...) directive are executed automatically by the assistant.
PLAYBOOK = {
    "benign_login": [
        "Confirm the login is from a previously seen device.",
        "@set_verdict(benign)",
    ],
    "port_scan": [
        "Correlate the source IP against threat intel feeds.",
        "@set_verdict(suspicious)",
    ],
    "malware_exec": [
        "@read_context(Qd2O7GbvI7kpLNh4p4MQ)",   # handle -> malware_exec.md
        "Match the process hash against the software allow-list.",
        "@set_verdict(malicious)",
        "@escalate(tier2)",
    ],
    "phishing_report": [
        "@read_context(RteX6X7OZYvmeoc=)",        # handle -> phishing.md
        "Check the sender domain reputation.",
        "@set_verdict(suspicious)",
    ],
    "followup": [
        "@read_context(SCKX8nDwYu3AWPk=)",        # handle -> followup.md
        "Re-check the indicators against the case history above.",
        "@set_verdict(suspicious)",
    ],
}

TOOLS = {"set_verdict", "read_context", "escalate"}

# The executor recognises a directive anywhere it appears in the plan text.
DIRECTIVE = re.compile(r"@\s*([A-Za-z_]\w*)\s*\(([^)]*)\)")


def sanitize(text):
    """Best-effort scrub of untrusted text before it becomes analyst context.

    Drops any line that begins with a tool directive, so an external feed cannot
    obviously smuggle a command into the plan.
    """
    kept = []
    for line in text.splitlines():
        if re.match(r"\s*@\s*[A-Za-z_]\w*\s*\(", line):
            continue
        kept.append(line)
    return "\n".join(kept)


def build_plan(alert):
    """Assemble the work plan: trusted playbook steps plus the alert's context note.

    For a `followup` alert we also fold in the case history so the executor's steps read
    with the earlier notes inline.
    """
    steps = list(PLAYBOOK.get(alert.get("type", ""), ["@set_verdict(unknown)"]))
    if alert.get("type") == "followup":
        prior = "\n".join(CASE_NOTES.get(alert.get("case", ""), []))
        steps.append("Prior case notes under review:\n" + prior)
    note = sanitize(str(alert.get("description", "")))
    steps.append("Analyst context for %s: %s" % (alert.get("id", "?"), note))
    return "\n".join(steps)


class Assistant:
    def __init__(self):
        self.verdict = None
        self.reads = []
        self.escalations = []
        self.report = []
        self.tool_log = []

    def _set_verdict(self, v):
        self.verdict = v

    def _read_context(self, handle):
        # the tool argument is an opaque handle; resolve it to a resource name first
        try:
            name = decode(handle)
        except Exception:
            self.reads.append(handle)
            return ""
        full = name if os.path.isabs(name) else os.path.join(CTX_DIR, name)
        self.reads.append(name)
        try:
            with open(full, "r", errors="replace") as f:
                data = f.read()
        except OSError:
            data = ""
        self.report.append(data)
        return data

    def _escalate(self, level):
        self.escalations.append(level)

    def execute(self, plan_text):
        text = unicodedata.normalize("NFKC", plan_text)
        for m in DIRECTIVE.finditer(text):
            name = m.group(1).lower()
            arg = m.group(2).strip()
            if name not in TOOLS:
                continue
            self.tool_log.append([name, arg])
            getattr(self, "_" + name)(arg)


def triage(alert):
    """Triage a single alert and return the resulting case record."""
    a = Assistant()
    a.execute(build_plan(alert))
    # append this alert's analyst note to the running case history, so a later followup
    # alert in the same case can review it.
    case = alert.get("case", alert.get("id"))
    CASE_NOTES.setdefault(case, []).append(
        "[%s/%s] %s" % (alert.get("id"), alert.get("type"),
                        sanitize(str(alert.get("description", "")))))
    return {
        "id": alert.get("id"),
        "verdict": a.verdict,
        "reads": a.reads,
        "escalations": a.escalations,
        "tool_log": a.tool_log,
        "report": "\n".join(a.report),
    }


if __name__ == "__main__":
    import json
    import sys

    raw = sys.stdin.read()
    alert = json.loads(raw) if raw.strip() else {
        "id": "A-DEMO", "type": "malware_exec", "severity": "high",
        "description": "explorer.exe spawned powershell with an encoded command.",
    }
    print(json.dumps(triage(alert), indent=2))
