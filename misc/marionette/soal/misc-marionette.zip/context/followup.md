# Context: followup

When a follow-up alert reopens a case:
- Re-read the case history and confirm whether the earlier verdict still holds.
- If new indicators contradict the prior verdict, raise severity and hand to tier2.
- Close the case only once every linked alert has been accounted for.
