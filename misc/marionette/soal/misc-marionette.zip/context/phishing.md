# Context: phishing_report

Triage steps for user-reported phishing:
- Detonate URLs in the sandbox, never on a live host.
- Compare the sender domain against the look-alike watch-list.
- If credentials were entered, open an account-compromise case and reset.
