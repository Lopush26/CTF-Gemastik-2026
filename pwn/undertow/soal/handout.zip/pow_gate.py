#!/usr/bin/env python3
"""
Proof-of-work gate.

On each connection the server prints a random challenge `chal` and a difficulty
`bits`; the client must present a suffix S such that SHA-256(chal + S) has at
least `bits` leading zero bits before the target binary is served.

Env:
  POW_BITS   difficulty in leading zero bits (default 22)
  TARGET     path to the target binary (default /app/undertow)
"""
import os
import sys
import hashlib
import secrets


def leading_zero_bits(digest: bytes) -> int:
    bits = 0
    for byte in digest:
        if byte == 0:
            bits += 8
            continue
        for i in range(7, -1, -1):
            if byte & (1 << i):
                return bits
            bits += 1
        break
    return bits


def main():
    bits = int(os.environ.get("POW_BITS", "22"))
    target = os.environ.get("TARGET", "/app/undertow")
    prefix = secrets.token_hex(16)

    sys.stdout.write(
        "== proof of work ==\n"
        f"find S such that sha256('{prefix}' + S) has {bits} leading zero bits\n"
        "send S: "
    )
    sys.stdout.flush()

    line = sys.stdin.readline()
    if not line:
        return
    suffix = line.strip()
    digest = hashlib.sha256((prefix + suffix).encode()).digest()
    if leading_zero_bits(digest) < bits:
        sys.stdout.write("pow: rejected\n")
        sys.stdout.flush()
        return

    sys.stdout.write("pow: ok\n")
    sys.stdout.flush()

    # hand over stdin/stdout to the real service
    os.execv(target, [target])


if __name__ == "__main__":
    main()
